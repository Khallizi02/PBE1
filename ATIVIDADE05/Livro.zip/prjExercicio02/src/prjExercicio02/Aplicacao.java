package prjExercicio02;

public class Aplicacao {
	
	public static void main(String[] args) {
	
	Livro livro1 = new Livro("Os esquizofrenicoszinhos", "Dona Rocha",230, 50.00, 35.00);
	Livro livro2 = new Livro("Pare de se odiar", "Alexandrismo", 500, 75.00, 60.00);
	Livro livro3 = new Livro("Tenho autismo", "Khallil", 2, 1000.00, 985.00);
	Livro livro4 = new Livro("Ariana Grande a melhor artista frv", "Khallil", 4256, 30.00, 15.00);
	Livro livro5 = new Livro("Espero q a Taylor Swifit morra", "Khallil", 1, 20.00, 5.00);
	
	livro1.metodoExibir();
	livro2.metodoExibir();
	livro3.metodoExibir();
	livro4.metodoExibir();
	livro5.metodoExibir();
	

}
}