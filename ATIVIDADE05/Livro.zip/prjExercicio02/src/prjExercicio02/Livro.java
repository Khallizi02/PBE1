package prjExercicio02;

public class Livro {

	//Atributos:
	
	private String titulo;
	private String autor;
	private int numPaginas;	
	private Double preco;
	private Double desconto;
	
	//Construtores
	
	public Livro() {
		
	}
	
	public Livro(String titulo, String autor, int numPaginas, Double preco, Double desconto) {
		this.titulo = titulo;
		this.autor = autor;
		this.numPaginas = numPaginas;
		this.preco = preco;
		this.desconto = desconto;
	}
	 
	//Getters e setters
	
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}
	
	public int getNumPaginas() {
		return numPaginas;
	}
	
	public void setNumPaginas(int numPaginas) {
		this.numPaginas = numPaginas;
			
	}
	public Double getPreco() {
		return preco;
	}
	
	public void setPreco(Double preco) {
		this.preco = preco;
}
	public Double getDesconto() {
		return preco;
	}
	
	public void setDesconto(Double desconto) {
		this.desconto = desconto;
	}
	
	//Metodos
	
	public void desconto(Double desconto) {
		desconto -= preco;
		
	}
	
	public void metodoExibir() {
		System.out.println("Titulo: " + this.titulo);
		System.out.println("Autor: " + this.autor);
		System.out.println("Numero de paginas: " + this.numPaginas);
		System.out.println("Preço: " + this.preco);
		System.out.println("Preco com desconto: " + this.desconto);
	}
}
