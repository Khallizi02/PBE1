package prjExercicio04;

public class subclasseCaminhão extends Veiculo{

	//Metodo da subclasse sobrescrito
	
	@Override 
	
	public void acelerar() {
		velocidade += 10;
		System.out.println("O caminhão da Isa safica aumentou a velocidade");
	}
}
