package prjExercicio04;

public class subclasseMoto extends Veiculo {
	
	//Metodo da subclasse sobrescrito
	
		@Override 
		
		public void frear() {
			velocidade -= 10;
			System.out.println("A moto da calopicita diminuiu a velocidade");
		}

}
