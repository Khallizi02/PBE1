package prjExercicio01;

public class Carro2 {

	public static void main(String[] args) {
		
		Carro carro01 = new Carro("Esquizofrenia","Captalismo","Rosa neon", 58);
		Carro2 carro02 = new Carro2("Borderline","Comunismo","De burro quando foge", 3);
		
		System.out.println("Primeiro carro: " + carro01);
		System.out.println("Segundo carro: " + carro02);

	}

}
