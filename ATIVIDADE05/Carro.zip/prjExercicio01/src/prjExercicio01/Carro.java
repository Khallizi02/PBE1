package prjExercicio01;

public class Carro {
		
		//Atributos do carro
		
		private String marca;
		private String modelo;
		private String cor;
		private int capacidadePassageiro;
		
		//Contrtutores do carro 1
		
		public Carro() {
			
		}
        
		public Carro(String marca, String modelo, String cor, int capacidadePassageiro) {
			this.marca = marca;
			this.modelo= modelo;
			this.cor = cor;
			this.capacidadePassageiro = capacidadePassageiro;
		}
		
		//Getters e setters

		public String getMarca() {
			return marca;
		}

		public void setMarca(String marca) {
			this.marca = marca;
		}

		public String getModelo() {
			return modelo;
		}

		public void setModelo(String modelo) {
			this.modelo = modelo;
		}

		public String getCor() {
			return cor;
		}

		public void setCor(String cor) {
			this.cor = cor;
		}

		public int getCapacidadePassageiro() {
			return capacidadePassageiro;
		}

		public void setCapacidadePassageiro(int capacidadePassageiro) {
			this.capacidadePassageiro = capacidadePassageiro;
		}
	
		//Metodos
		
		public void exibir() {
			System.out.println("Marca: " + this.marca);
	    	System.out.println("Modelo: " + this.modelo);
	    	System.out.println("Cor: " + this.cor);
	    	System.out.println("Capacidade de passageiros: " + this.capacidadePassageiro);
			
		
	
		
		}	

}
