package prjExercicio3;

public class subclasseBaleia extends Animal {
	
	//metodos da subclasse
	
		 public void metodoNadar() {
				System.out.println(this.nome + " está nadando :) ");
			}

   // Outro negocio pra mudar o som @o@ 
		 @Override 
			public void fazerSom() {
				System.out.println("WOOOOOWON");
			}
}
