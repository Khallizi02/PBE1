package prjExercicio3;

public class subclasseLeao extends Animal {
	
	//metodos da subclasse
	
	 public void metodoCacar() {
			System.out.println(this.nome + " está caçando");
		}
	 
	 
	 //Baugulho pra mudar o som :D
	 @Override 
		public void fazerSom() {
			System.out.println("ROOOOOAAAR - Katy Perry");
		}

}
