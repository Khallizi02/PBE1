import java.util.Scanner;

public class prjContaBancaria {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		
		System.out.println("Qual o numero da conta?");
		int numeroConta = sc.nextInt();
		
		System.out.println("Qual o nome do titular da conta?");
		String nomeTitular = sc.nextLine();
		
		System.out.println("Qual o saldo atual da conta?");
		double saldo = sc.nextDouble();
		
		System.out.println("Voce quer sacar ou depositar?");
		System.out.println("1. Sacar");
		System.out.println("2. Depositar")
		int escolha = sc.nextInt().Int();
		
		if (escolha == 1) {
			
		}
		
		

	}

}
