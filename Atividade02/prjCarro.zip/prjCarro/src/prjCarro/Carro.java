package prjCarro;

import java.util.Scanner;

public class Carro {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		

	    
	    System.out.println("Qual é a marca do carro?");
	    String marca = sc.next();
	    
	    System.out.println("Qual o modelo do carro?");
	    String modelo = sc.next();
	    
	    System.out.println("Qual a velocidade inicial do carro?");
	    int velocidade = sc.nextInt();
	    
		System.out.println("Você gostaria de acelerar ou freiar?");
		System.out.println("Opção:");
		System.out.println("1. Acelerar");
		System.out.println("2. Frear");
		System.out.print("Escolha uma opção: ");
		int escolha = sc.nextInt();
		
		if (escolha == 1) {
			System.out.println("Quanto você quer acelerar?");
			int valor = sc.nextInt();
			velocidade += valor;
		}
		else if (escolha == 2) {
			System.out.println("Quanto você quer frear?");
			int valor = sc.nextInt();
			velocidade -= valor;
		}
		
		else { 
			System.out.println("Opção invalida");
		}
		
		
		
		
		

	}

}
